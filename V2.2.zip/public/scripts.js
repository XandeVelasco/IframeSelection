function TemaIchi(){
    window.location.href = 'gridData.html';
};

function TemaNi(){
     window.location.href = 'gridTrabalho.html';
};

function TemaSan(){
    window.location.href = 'gridIndustria.html';
};

function TemaYon(){
     window.location.href = 'gridTecnologia.html';
};

function TemaGo(){
     window.location.href = 'gridMacrossetorial.html';
};

function TemaRoku(){
    window.location.href = 'gridSaude.html';
};

function TemaNana(){
     window.location.href = 'gridEducacao.html';
};

function TemaHachi(){
     window.location.href = 'gridMulheres.html';
};

function TemaKyu(){
    window.location.href = 'temas.html';
};

// Grid next page

function GoToNextGo(){
    window.location.href = 'gridMacrossetorial2.html';
}

function GoToNextGo2(){
    window.location.href = 'gridMacrossetorial3.html';
}

function GoToNexthACHI(){
    window.location.href = 'gridMulheres2.html';
}

function GoToNextYon(){
    window.location.href = 'gridTecnologia2.html';
}

function GoToNextYon2(){
    window.location.href = 'gridTecnologia3.html';
}

function GoToNextNi(){
    window.location.href = 'gridTrabalho2.html';
}
function GoToNextNi2(){
    window.location.href = 'gridTrabalho3.html';
}
function GoToNextNi3(){
    window.location.href = 'gridTrabalho4.html';
}

function GoToNextSan(){
    window.location.href = 'gridIndustria2.html';
}

function GoToNextSan2(){
    window.location.href = 'gridIndustria3.html';
}

function GoToNextNana(){
    window.location.href = 'gridEducacao2.html';
}
//   GRIDS //

function DataDriven_1(){
    window.location.href = 'datadriven_1.html';
};

function DataDriven_2(){
    window.location.href = 'datadriven_2.html';
};

 // educacao //

function Educacao_1(){
    window.location.href = 'educacao_1.html';
};

function Educacao_2(){
    window.location.href = 'educacao_2.html';
};

function Educacao_3(){
    window.location.href = 'educacao_3.html';
};

function Educacao_4(){
    window.location.href = 'educacao_4.html';
};

function Educacao_5(){
    window.location.href = 'educacao_5.html';
};

// mulheres //

function Mulheres_1(){
    window.location.href = 'mulheres_1.html';
};

function Mulheres_2(){
    window.location.href = 'mulheres_2.html';
};

function Mulheres_3(){
    window.location.href = 'mulheres_3.html';
};

function Mulheres_4(){
    window.location.href = 'mulheres_4.html';
};

function Mulheres_5(){
    window.location.href = 'mulheres_5.html';
};

function Mulheres_6(){
    window.location.href = 'mulheres_6.html';
};

function Mulheres_7(){
    window.location.href = 'mulheres_7.html';
};

// saude //

function Saude_1(){
    window.location.href = 'saude_1.html';
};

function Saude_2(){
    window.location.href = 'saude_2.html';
};

function Saude_3(){
    window.location.href = 'saude_3.html';
};

function Saude_4(){
    window.location.href = 'saude_4.html';
};

// tecnologia //

function Tecnologia_1(){
    window.location.href = 'tecnologia_1.html';
};

function Tecnologia_2(){
    window.location.href = 'tecnologia_2.html';
};

function Tecnologia_3(){
    window.location.href = 'tecnologia_3.html';
};

function Tecnologia_4(){
    window.location.href = 'tecnologia_4.html';
};

function Tecnologia_5(){
    window.location.href = 'tecnologia_5.html';
};

function Tecnologia_6(){
    window.location.href = 'tecnologia_6.html';
};

function Tecnologia_7(){
    window.location.href = 'tecnologia_7.html';
};

function Tecnologia_8(){
    window.location.href = 'tecnologia_8.html';
};

function Tecnologia_9(){
    window.location.href = 'tecnologia_9.html';
};

// trabalho //

function Trabalho_1(){
    window.location.href = 'trabalho_1.html';
};

function Trabalho_2(){
    window.location.href = 'trabalho_2.html';
};

function Trabalho_3(){
    window.location.href = 'trabalho_3.html';
};

function Trabalho_4(){
    window.location.href = 'trabalho_4.html';
};

function Trabalho_5(){
    window.location.href = 'trabalho_5.html';
};

function Trabalho_6(){
    window.location.href = 'trabalho_6.html';
};

function Trabalho_7(){
    window.location.href = 'trabalho_7.html';
};

function Trabalho_8(){
    window.location.href = 'trabalho_8.html';
};
function Trabalho_9(){
    window.location.href = 'trabalho_9.html';
};
function Trabalho_10(){
    window.location.href = 'trabalho_10.html';
};
function Trabalho_11(){
    window.location.href = 'trabalho_11.html';
};
function Trabalho_12(){
    window.location.href = 'trabalho_12.html';
};
function Trabalho_13(){
    window.location.href = 'trabalho_13.html';
};
function Trabalho_14(){
    window.location.href = 'trabalho_14.html';
};
function Trabalho_15(){
    window.location.href = 'trabalho_15.html';
};

// macrossetoria //

function Macrossetorial_1(){
    window.location.href = 'macrossetorial_1.html';
};

function Macrossetorial_2(){
    window.location.href = 'macrossetorial_2.html';
};

function Macrossetorial_3(){
    window.location.href = 'macrossetorial_3.html';
};

function Macrossetorial_4(){
    window.location.href = 'macrossetorial_4.html';
};

function Macrossetorial_5(){
    window.location.href = 'macrossetorial_5.html';
};

function Macrossetorial_6(){
    window.location.href = 'macrossetorial_6.html';
};

function Macrossetorial_7(){
    window.location.href = 'macrossetorial_7.html';
};

function Macrossetorial_8(){
    window.location.href = 'macrossetorial_8.html';
};

function Macrossetorial_9(){
    window.location.href = 'macrossetorial_9.html';
};

// industria //

function Industria_1(){
    window.location.href = 'industria_1.html';
};

function Industria_2(){
    window.location.href = 'industria_2.html';
};

function Industria_3(){
    window.location.href = 'industria_3.html';
};

function Industria_4(){
    window.location.href = 'industria_4.html';
};

function Industria_5(){
    window.location.href = 'industria_5.html';
};

function Industria_6(){
    window.location.href = 'industria_6.html';
};

function Industria_7(){
    window.location.href = 'industria_7.html';
};

function Industria_8(){
    window.location.href = 'industria_8.html';
};

function Industria_9(){
    window.location.href = 'industria_9.html';
};



//voltar function
function Voltar(){
    
};

function GoToMenu(){
    window.location.href = 'index.html';
}

// Next buttons for full Screen section

// Data
function GoToNextFullData0(){
    window.location.href = 'datadriven_1.html';
}

function GoToNextFullData(){
    window.location.href = 'datadriven_2.html';
}



// Saude
function GoToNextFullSaude0(){
    window.location.href = 'saude_1.html';
}
function GoToNextFullSaude(){
    window.location.href = 'saude_2.html';
}
function GoToNextFullSaude2(){
    window.location.href = 'saude_3.html';
}
function GoToNextFullSaude3(){
    window.location.href = 'saude_4.html';
}

// Tecnologia
function GoToNextFullTecnologia0(){
    window.location.href = 'tecnologia_1.html';
}
function GoToNextFullTecnologia(){
    window.location.href = 'tecnologia_2.html';
}
function GoToNextFullTecnologia2(){
    window.location.href = 'tecnologia_3.html';
}
function GoToNextFullTecnologia3(){
    window.location.href = 'tecnologia_4.html';
}
function GoToNextFullTecnologia4(){
    window.location.href = 'tecnologia_5.html';
}
function GoToNextFullTecnologia5(){
    window.location.href = 'tecnologia_6.html';
}
function GoToNextFullTecnologia6(){
    window.location.href = 'tecnologia_7.html';
}
function GoToNextFullTecnologia7(){
    window.location.href = 'tecnologia_8.html';
}
function GoToNextFullTecnologia8(){
    window.location.href = 'tecnologia_9.html';
}

// Mulheres
function GoToNextFullMulheres0(){
    window.location.href = 'mulheres_1.html';
}
function GoToNextFullMulheres(){
    window.location.href = 'mulheres_2.html';
}
function GoToNextFullMulheres2(){
    window.location.href = 'mulheres_3.html';
}
function GoToNextFullMulheres3(){
    window.location.href = 'mulheres_4.html';
}
function GoToNextFullMulheres4(){
    window.location.href = 'mulheres_5.html';
}
function GoToNextFullMulheres5(){
    window.location.href = 'mulheres_6.html';
}
function GoToNextFullMulheres6(){
    window.location.href = 'mulheres_7.html';
}

// Industria
function GoToNextFullIndustria0(){
    window.location.href = 'industria_1.html';
}
function GoToNextFullIndustria(){
    window.location.href = 'industria_2.html';
}
function GoToNextFullIndustria2(){
    window.location.href = 'industria_3.html';
}
function GoToNextFullIndustria3(){
    window.location.href = 'industria_4.html';
}
function GoToNextFullIndustria4(){
    window.location.href = 'industria_5.html';
}
function GoToNextFullIndustria5(){
    window.location.href = 'industria_6.html';
}
function GoToNextFullIndustria6(){
    window.location.href = 'industria_7.html';
}
function GoToNextFullIndustria7(){
    window.location.href = 'industria_8.html';
}
function GoToNextFullIndustria8(){
    window.location.href = 'industria_9.html';
}

// Trabalho
function GoToNextFullTrabalho0(){
    window.location.href = 'trabalho_1.html';
}
function GoToNextFullTrabalho(){
    window.location.href = 'trabalho_2.html';
}
function GoToNextFullTrabalho2(){
    window.location.href = 'trabalho_3.html';
}
function GoToNextFullTrabalho3(){
    window.location.href = 'trabalho_4.html';
}
function GoToNextFullTrabalho4(){
    window.location.href = 'trabalho_5.html';
}
function GoToNextFullTrabalho5(){
    window.location.href = 'trabalho_6.html';
}
function GoToNextFullTrabalho6(){
    window.location.href = 'trabalho_7.html';
}
function GoToNextFullTrabalho7(){
    window.location.href = 'trabalho_8.html';
}
function GoToNextFullTrabalho8(){
    window.location.href = 'trabalho_9.html';
}
function GoToNextFullTrabalho9(){
    window.location.href = 'trabalho_10.html';
}
function GoToNextFullTrabalho10(){
    window.location.href = 'trabalho_11.html';
}
function GoToNextFullTrabalho11(){
    window.location.href = 'trabalho_12.html';
}
function GoToNextFullTrabalho12(){
    window.location.href = 'trabalho_13.html';
}
function GoToNextFullTrabalho13(){
    window.location.href = 'trabalho_14.html';
}
function GoToNextFullTrabalho14(){
    window.location.href = 'trabalho_15.html';
}

// Educacao
function GoToNextFullEducacao0(){
    window.location.href = 'educacao_1.html';
}
function GoToNextFullEducacao(){
    window.location.href = 'educacao_2.html';
}
function GoToNextFullEducacao2(){
    window.location.href = 'educacao_3.html';
}
function GoToNextFullEducacao3(){
    window.location.href = 'educacao_4.html';
}
function GoToNextFullEducacao4(){
    window.location.href = 'educacao_5.html';
}

// Macro
function GoToNextFullMacro0(){
    window.location.href = 'macrossetorial_1.html';
}
function GoToNextFullMacro(){
    window.location.href = 'macrossetorial_2.html';
}
function GoToNextFullMacro2(){
    window.location.href = 'macrossetorial_3.html';
}
function GoToNextFullMacro3(){
    window.location.href = 'macrossetorial_4.html';
}
function GoToNextFullMacro4(){
    window.location.href = 'macrossetorial_5.html';
}
function GoToNextFullMacro5(){
    window.location.href = 'macrossetorial_6.html';
}
function GoToNextFullMacro6(){
    window.location.href = 'macrossetorial_7.html';
}
function GoToNextFullMacro7(){
    window.location.href = 'macrossetorial_8.html';
}
function GoToNextFullMacro8(){
    window.location.href = 'macrossetorial_9.html';
}

// Go to grids

//Data
function GoToGridData1(){
    window.location.href = 'gridData.html';
}

//Educação
function GoToGridEducacao1(){
    window.location.href = 'gridEducacao.html';
}
function GoToGridEducacao2(){
    window.location.href = 'gridEducacao2.html';
}
//Industria
function GoToGridIndustria1(){
    window.location.href = 'gridIndustria.html';
}
function GoToGridIndustria2(){
    window.location.href = 'gridIndustria2.html';
}
function GoToGridIndustria3(){
    window.location.href = 'gridIndustria3.html';
}
//Macrossetorial
function GoToGridMacro1(){
    window.location.href = 'gridMacrossetorial.html';
}
function GoToGridMacro2(){
    window.location.href = 'gridMacrossetorial2.html';
}
function GoToGridMacro3(){
    window.location.href = 'gridMacrossetorial3.html';
}
//Mulheres
function GoToGridMulher1(){
    window.location.href = 'gridMulheres.html';
}
function GoToGridMulher2(){
    window.location.href = 'gridMulheres2.html';
}
//Saude
function GoToGridSaude1(){
    window.location.href = 'gridSaude.html';
}
//Tecnologia
function GoToGridTecnologia1(){
    window.location.href = 'gridTecnologia.html';
}
function GoToGridTecnologia2(){
    window.location.href = 'gridTecnologia2.html';
}
function GoToGridTecnologia3(){
    window.location.href = 'gridTecnologia3.html';
}
//Trabalho
function GoToGridTrabalho1(){
    window.location.href = 'gridTrabalho.html';
}
function GoToGridTrabalho2(){
    window.location.href = 'gridTrabalho2.html';
}
function GoToGridTrabalho3(){
    window.location.href = 'gridTrabalho3.html';
}
function GoToGridTrabalho4(){
    window.location.href = 'gridTrabalho4.html';
}

// Navegtação entre os grids